import pylrc

def writerpy(msg):
    file = open("in.srt","a",encoding="utf-8")
    file.write(str(msg))
    file.write("\n")
    file.close()

lrc_file = open('in.lrc')
lrc_string = ''.join(lrc_file.readlines())
lrc_file.close()

subs = pylrc.parse(lrc_string)


srt = subs.toSRT() # convert lrc to srt string

print(srt)
writerpy(srt)