import pysrt
srt = pysrt.open("in.srt")

def writerpy(msg,m):
    file = open(str(m)+".rpy","a+",encoding="utf-8")
    file.write(str(msg))
    file.write("\n")
    file.close()

def get_f_t(label_t):
    timestr=str(label_t)
    timel1=timestr.split(",")
    timel2=timel1[0]
    timel2=timel2.split(":")
    timems=int(timel1[1])/1000
    time=timems+int(timel2[2])+int(timel2[1])*60+int(timel2[0])*60*60
    return time

def gettime(s,e,):
    return get_f_t(e)-get_f_t(s)

def prepare():
    writerpy("""
image bg="#000"

style t:
    size 260
    color "#ffffff"
    font "SentyTEA.ttf" 

label start:
    scene bg
    play music "song.mp3"
""", "main")

if __name__=="__main__":
    prepare()
    for i in range(len(srt)):
        content = srt.data[i]
        #print(content.text_without_tags)
        texts=content.text_without_tags
        writerpy("""image b"""+str(i)+"""= Text(' """+str(texts)+""" ',style="t")""","pic")
        if i !=0:
            writerpy("""    $renpy.pause("""+str(gettime(str(srt.data[i-1].start),str(content.start)))+",hard=True)", "main")
        writerpy("""    show b"""+str(i)+"", "main")
        if i !=0:
            writerpy("    hide b"+str(i-1),"main")

    writerpy("    return", "main")
